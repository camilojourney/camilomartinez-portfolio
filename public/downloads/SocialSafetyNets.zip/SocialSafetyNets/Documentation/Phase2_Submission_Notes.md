# Phase II Submission Notes

Use these notes when you refresh the Word/PDF submission after taking new screenshots from the updated dashboard.

## Required screenshots

1. Full dashboard
2. Viz 1: choropleth map
3. Viz 2: time series
4. Viz 3: scatterplot
5. Viz 4: box plot

## Suggested writeups

### Viz 1 — Geospatial Map

The 2023 map shows a strong regional clustering pattern: Nordic and Western European countries dominate the top end of the happiness scale, while the lowest scores are concentrated in conflict-affected and lower-income states. Coverage is imperfect because some countries lack WHR values or harmonized ISO-3 codes, and the WHR itself is reported as a rolling three-year average rather than a pure point-in-time snapshot.

### Viz 2 — Time Series

Across the 2015-2023 panel, the High-spending tier stays above the Low-spending tier every year, which is consistent with the project hypothesis. The gap widens during the COVID period and narrows in 2023, suggesting that stronger safety nets may have buffered disruption, though the comparison is OECD-only because comparable spending data are not available globally.

### Viz 3 — Scatterplot

The selected-year scatterplot shows a moderate positive relationship between social spending and happiness, but the spread of points makes clear that spending alone does not determine wellbeing. Ireland is a notable outlier because its GDP denominator makes social spending look unusually low relative to its income and happiness levels.

### Viz 4 — Box Plot

The box plot shows that High- and Medium-spending countries overlap substantially, but the Low-spending tier is shifted downward with a lower median and more low-end observations. This supports the idea of diminishing returns after a moderate spending threshold rather than a simple one-to-one payoff from spending more.

## Narrative summary prompts

- Early conclusion: higher-spending countries tend to report higher subjective wellbeing, but the relationship is moderate rather than absolute.
- Main surprises: the COVID-era widening of the High-vs-Low gap, the overlap between High and Medium tiers, and denominator-driven outliers such as Ireland.
- Main roadblocks: OECD-only spending coverage, country-name harmonization, missing ISO-3 matches, and the rolling-average nature of the WHR scores.
