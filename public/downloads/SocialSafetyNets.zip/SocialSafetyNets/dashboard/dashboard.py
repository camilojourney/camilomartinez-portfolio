"""
CIS 9655 — Group 6 Phase II Dashboard
Social Safety Nets & Subjective Wellbeing

Plotly Dash app with four visualizations in a 2x2 grid:
  Viz 1 — Choropleth: Happiness Score by Country (year slider, 2015-2023)
  Viz 2 — Time Series: Average Happiness by Social-Spending Tier, 2015-2023
  Viz 3 — Scatterplot: Social Spending vs Happiness (selected year)
  Viz 4 — Scatterplot: GDP per capita (PPP) vs Happiness, colored by Spending Tier

Run with:    python dashboard.py
Then open:   http://127.0.0.1:8050
"""
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dash import Dash, Input, Output, State, ctx, dcc, html, no_update

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data_clean"

TIER_ORDER = ["High spending", "Medium spending", "Low spending"]
TIER_COLORS = {
    "High spending": "#1F7A8C",
    "Medium spending": "#F0A202",
    "Low spending": "#D95D39",
}
ACCENT_COLORS = {
    "map": "#69B9FF",
    "time": "#F0A202",
    "scatter": "#55D6A0",
    "distribution": "#FF8A6C",
}
THEME = {
    "bg": "#F4EFE6",
    "panel": "#FBF8F2",
    "ink": "#14213D",
    "muted": "#5B6470",
    "line": "#DCCFB6",
    "shadow": "0 20px 50px rgba(20, 33, 61, 0.10)",
    "hero_shadow": "0 24px 70px rgba(7, 17, 32, 0.30)",
    "title_font": "Georgia, 'Palatino Linotype', 'Book Antiqua', serif",
    "body_font": "'Avenir Next', 'Trebuchet MS', Verdana, sans-serif",
}

df = pd.read_csv(DATA_DIR / "merged_panel.csv")
df["year"] = pd.to_numeric(df["year"], errors="coerce").astype("Int64")
for column in ["happiness_score", "social_spending_pct_gdp", "gdp_per_capita_ppp"]:
    df[column] = pd.to_numeric(df[column], errors="coerce")

df["regional_indicator"] = df["regional_indicator"].fillna("").replace("", "Region not reported")
df["spending_tier"] = pd.Categorical(
    df["spending_tier"].replace("", pd.NA),
    categories=TIER_ORDER,
    ordered=True,
)
df = df.dropna(subset=["year", "happiness_score", "iso3"]).copy()
df["year"] = df["year"].astype(int)

YEARS = sorted(df["year"].unique())
DEFAULT_YEAR = max(YEARS)
COUNTRY_OPTIONS = [
    {"label": c, "value": c}
    for c in sorted(df["country"].dropna().unique())
]


def format_spending(value: float) -> str:
    if pd.isna(value):
        return "No comparable OECD spending data"
    return f"{value:.1f}% of GDP"


def format_gdp(value: float) -> str:
    if pd.isna(value):
        return "No GDP data"
    return f"${value:,.0f}"


def summarize_panel() -> dict:
    current = df[df["year"] == DEFAULT_YEAR].copy()
    comparable = current[current["social_spending_pct_gdp"].notna()].copy()

    high_mean = (
        df[df["spending_tier"] == "High spending"]["happiness_score"].mean()
    )
    low_mean = (
        df[df["spending_tier"] == "Low spending"]["happiness_score"].mean()
    )
    corr = comparable["social_spending_pct_gdp"].corr(comparable["happiness_score"])
    slope, intercept = pd.Series(
        comparable["happiness_score"]
    ).pipe(
        lambda y: (
            comparable["social_spending_pct_gdp"].cov(y)
            / comparable["social_spending_pct_gdp"].var(),
            y.mean()
            - (
                comparable["social_spending_pct_gdp"].cov(y)
                / comparable["social_spending_pct_gdp"].var()
            )
            * comparable["social_spending_pct_gdp"].mean(),
        )
    )
    fitted = intercept + slope * comparable["social_spending_pct_gdp"]
    ss_tot = ((comparable["happiness_score"] - comparable["happiness_score"].mean()) ** 2).sum()
    ss_res = ((comparable["happiness_score"] - fitted) ** 2).sum()
    r2 = 1 - (ss_res / ss_tot)

    return {
        "countries": int(current["country"].nunique()),
        "comparable": int(comparable["country"].nunique()),
        "corr": round(corr, 2),
        "r2": round(r2, 2),
        "gap": round(high_mean - low_mean, 2),
    }


SUMMARY = summarize_panel()


def apply_figure_theme(fig: go.Figure, height: int = 380) -> go.Figure:
    fig.update_layout(
        font=dict(family=THEME["body_font"], color=THEME["ink"], size=12),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=55, r=22, t=14, b=72),
        height=height,
    )
    fig.update_xaxes(
        showline=True,
        linecolor="#B9B09D",
        gridcolor="rgba(91, 100, 112, 0.12)",
        zeroline=False,
        tickfont=dict(color=THEME["muted"]),
        title_font=dict(color=THEME["muted"]),
    )
    fig.update_yaxes(
        showline=True,
        linecolor="#B9B09D",
        gridcolor="rgba(91, 100, 112, 0.12)",
        zeroline=False,
        tickfont=dict(color=THEME["muted"]),
        title_font=dict(color=THEME["muted"]),
    )
    return fig


REGION_SCOPE = {
    "Western Europe": "europe",
    "Central and Eastern Europe": "europe",
    "Commonwealth of Independent States": "asia",
    "South Asia": "asia",
    "Southern Asia": "asia",
    "Southeast Asia": "asia",
    "Southeastern Asia": "asia",
    "East Asia": "asia",
    "Eastern Asia": "asia",
    "Sub-Saharan Africa": "africa",
    "Middle East and North Africa": "africa",
    "Middle East and Northern Africa": "africa",
    "North America": "north america",
    "North America and ANZ": "north america",
    "Latin America and Caribbean": "south america",
}


def build_choropleth(year: int, selected_country: str | None = None) -> go.Figure:
    """Choropleth of happiness by country for a given year.

    When a country is selected the map zooms to the surrounding region (Plotly's
    built-in scope) and that country gets a heavy outline so it pops out.
    """
    sub = df[df["year"] == year].copy()
    sub["social_spending_label"] = sub["social_spending_pct_gdp"].map(format_spending)
    sub["gdp_label"] = sub["gdp_per_capita_ppp"].map(format_gdp)

    fig = px.choropleth(
        sub,
        locations="iso3",
        color="happiness_score",
        hover_name="country",
        custom_data=[
            "country",
            "happiness_score",
            "social_spending_label",
            "gdp_label",
        ],
        color_continuous_scale=[
            [0.0, "#C84C31"],
            [0.35, "#F0A202"],
            [0.65, "#D5E9F6"],
            [1.0, "#2166AC"],
        ],
        range_color=(2.5, 8.0),
        labels={"happiness_score": "Happiness"},
    )
    fig.update_traces(
        hovertemplate=(
            "<b>%{customdata[0]}</b><br>"
            "Happiness score: %{customdata[1]:.2f}<br>"
            "Social spending: %{customdata[2]}<br>"
            "GDP per capita (PPP): %{customdata[3]}"
            "<extra></extra>"
        )
    )

    if selected_country and selected_country in sub["country"].values:
        sel_iso = sub.loc[sub["country"] == selected_country, "iso3"].iloc[0]
        country_regions = (
            df.loc[
                (df["country"] == selected_country)
                & (df["regional_indicator"] != "Region not reported"),
                "regional_indicator",
            ]
            .dropna()
        )
        sel_region = country_regions.iloc[0] if not country_regions.empty else "Region not reported"
        outline = [3 if iso == sel_iso else 0.4 for iso in sub["iso3"]]
        fig.update_traces(marker_line_width=outline, marker_line_color="#14213D")
        scope = REGION_SCOPE.get(sel_region, "world")
    else:
        scope = "world"

    geo_kwargs = dict(
        showframe=False,
        showcoastlines=False,
        bgcolor="rgba(0,0,0,0)",
        showland=True,
        landcolor="#EFE7DA",
        showcountries=True,
        countrycolor="rgba(91, 100, 112, 0.22)",
    )
    if scope == "world":
        geo_kwargs["projection_type"] = "natural earth"
    else:
        geo_kwargs["scope"] = scope

    fig.update_layout(
        geo=geo_kwargs,
        coloraxis_colorbar=dict(
            title=dict(text="Happiness<br>score", side="top"),
            thickness=12,
            len=0.72,
            outlinewidth=0,
        ),
        margin=dict(l=0, r=0, t=10, b=6),
        height=380,
        font=dict(family=THEME["body_font"], color=THEME["ink"], size=12),
        paper_bgcolor="rgba(0,0,0,0)",
    )
    return fig


def build_time_series(selected_country: str | None = None) -> go.Figure:
    """Mean happiness over time by spending tier, with a COVID-era band.

    When a country is selected its own time series is overlaid in bold so the
    user can see how that country tracks the tier averages.
    """
    panel = df.dropna(subset=["spending_tier"]).copy()
    avg = (
        panel.groupby(["year", "spending_tier"], observed=True)["happiness_score"]
        .mean()
        .reset_index()
    )
    counts = (
        panel.groupby(["year", "spending_tier"], observed=True)["country"]
        .nunique()
        .reset_index(name="n_countries")
    )
    avg = avg.merge(counts, on=["year", "spending_tier"])

    fig = go.Figure()
    dash_styles = {
        "High spending": "solid",
        "Medium spending": "dash",
        "Low spending": "dot",
    }

    for tier in TIER_ORDER:
        tier_data = avg[avg["spending_tier"] == tier].sort_values("year")
        fig.add_trace(
            go.Scatter(
                x=tier_data["year"],
                y=tier_data["happiness_score"],
                mode="lines+markers",
                name=tier,
                line=dict(color=TIER_COLORS[tier], width=4, dash=dash_styles[tier]),
                marker=dict(
                    size=9,
                    color=TIER_COLORS[tier],
                    line=dict(color="#FBF8F2", width=1.5),
                ),
                customdata=tier_data[["n_countries"]],
                hovertemplate=(
                    f"<b>{tier}</b><br>"
                    "Year: %{x}<br>"
                    "Average happiness: %{y:.2f}<br>"
                    "n = %{customdata[0]} countries"
                    "<extra></extra>"
                ),
            )
        )

    if selected_country:
        country_data = (
            df[df["country"] == selected_country]
            .sort_values("year")
        )
        if not country_data.empty:
            fig.add_trace(
                go.Scatter(
                    x=country_data["year"],
                    y=country_data["happiness_score"],
                    mode="lines+markers",
                    name=selected_country,
                    line=dict(color="#14213D", width=4),
                    marker=dict(
                        size=11,
                        color="#14213D",
                        line=dict(color="#FBF8F2", width=2),
                    ),
                    hovertemplate=(
                        f"<b>{selected_country}</b><br>"
                        "Year: %{x}<br>"
                        "Happiness: %{y:.2f}"
                        "<extra></extra>"
                    ),
                )
            )

    fig.add_vrect(
        x0=2019.5,
        x1=2021.5,
        fillcolor="rgba(20, 33, 61, 0.08)",
        line_width=0,
        annotation_text="COVID-era shock window",
        annotation_position="top left",
        annotation_font=dict(size=11, color=THEME["muted"]),
    )

    fig.update_layout(
        xaxis=dict(title="Year", dtick=1),
        yaxis=dict(title="Average Cantril ladder", autorange=True),
        legend=dict(
            orientation="h",
            y=-0.22,
            x=0.5,
            xanchor="center",
            title=None,
            bgcolor="rgba(0,0,0,0)",
        ),
        hovermode="x unified",
    )
    return apply_figure_theme(fig)


def _add_tier_scatter(
    fig: go.Figure,
    sub: pd.DataFrame,
    x_col: str,
    y_col: str,
    selected_country: str | None,
    hover: str,
    custom_cols: list[str],
) -> None:
    """Add per-tier dots + trend lines that share a legendgroup.

    Sharing a legendgroup means clicking a tier in the legend hides BOTH the
    dots and the dashed trend line for that tier together.
    """
    for tier in TIER_ORDER:
        tier_data = sub[sub["spending_tier"] == tier]
        if tier_data.empty:
            continue

        sizes = [
            18 if c == selected_country else 11
            for c in tier_data["country"]
        ]
        opacities = [
            1.0 if c == selected_country else (0.35 if selected_country else 0.85)
            for c in tier_data["country"]
        ]
        line_widths = [
            3 if c == selected_country else 1.2
            for c in tier_data["country"]
        ]
        line_colors = [
            "#14213D" if c == selected_country else "#FBF8F2"
            for c in tier_data["country"]
        ]

        fig.add_trace(
            go.Scatter(
                x=tier_data[x_col],
                y=tier_data[y_col],
                mode="markers",
                name=tier,
                legendgroup=tier,
                marker=dict(
                    size=sizes,
                    color=TIER_COLORS[tier],
                    opacity=opacities,
                    line=dict(width=line_widths, color=line_colors),
                ),
                customdata=tier_data[custom_cols].to_numpy(),
                hovertemplate=hover,
            )
        )

        if len(tier_data) < 2:
            continue
        x = tier_data[x_col]
        y = tier_data[y_col]
        x_mean, y_mean = x.mean(), y.mean()
        denom = ((x - x_mean) ** 2).sum()
        if denom == 0:
            continue
        slope = ((x - x_mean) * (y - y_mean)).sum() / denom
        intercept = y_mean - slope * x_mean
        x_line = [x.min(), x.max()]
        y_line = [intercept + slope * xv for xv in x_line]
        fig.add_trace(
            go.Scatter(
                x=x_line,
                y=y_line,
                mode="lines",
                name=f"{tier} trend",
                legendgroup=tier,
                showlegend=False,
                line=dict(color=TIER_COLORS[tier], width=2, dash="dot"),
                hoverinfo="skip",
            )
        )


def build_scatter(year: int, selected_country: str | None = None) -> go.Figure:
    """Spending vs happiness, with per-tier trend lines and country highlight."""
    sub = df[
        (df["year"] == year)
        & df["social_spending_pct_gdp"].notna()
        & df["spending_tier"].notna()
    ].copy()
    sub["gdp_label"] = sub["gdp_per_capita_ppp"].map(format_gdp)

    fig = go.Figure()
    hover = (
        "<b>%{customdata[0]}</b><br>"
        "Social spending: %{customdata[1]:.1f}% of GDP<br>"
        "Happiness score: %{customdata[2]:.2f}<br>"
        "GDP per capita (PPP): %{customdata[3]}"
        "<extra></extra>"
    )
    _add_tier_scatter(
        fig,
        sub,
        x_col="social_spending_pct_gdp",
        y_col="happiness_score",
        selected_country=selected_country,
        hover=hover,
        custom_cols=["country", "social_spending_pct_gdp", "happiness_score", "gdp_label"],
    )
    fig.update_layout(
        xaxis=dict(title="Public social spending (% of GDP)"),
        yaxis=dict(title="Happiness score", range=[4.0, 8.0]),
        legend=dict(
            orientation="h",
            y=-0.22,
            x=0.5,
            xanchor="center",
            title=None,
            bgcolor="rgba(0,0,0,0)",
        ),
    )
    return apply_figure_theme(fig)


def build_gdp_vs_happiness(year: int, selected_country: str | None = None) -> go.Figure:
    """GDP per capita (PPP) vs happiness — controls for the wealth confounder."""
    sub = df[
        (df["year"] == year)
        & df["gdp_per_capita_ppp"].notna()
        & df["spending_tier"].notna()
    ].copy()

    fig = go.Figure()
    hover = (
        "<b>%{customdata[0]}</b><br>"
        "GDP per capita (PPP): $%{customdata[1]:,.0f}<br>"
        "Happiness score: %{customdata[2]:.2f}<br>"
        "Social spending: %{customdata[3]:.1f}% of GDP"
        "<extra></extra>"
    )
    _add_tier_scatter(
        fig,
        sub,
        x_col="gdp_per_capita_ppp",
        y_col="happiness_score",
        selected_country=selected_country,
        hover=hover,
        custom_cols=["country", "gdp_per_capita_ppp", "happiness_score", "social_spending_pct_gdp"],
    )
    fig.update_layout(
        xaxis=dict(title="GDP per capita, PPP (USD)", type="log"),
        yaxis=dict(title="Happiness score", range=[2.5, 8.0]),
        legend=dict(
            orientation="h",
            y=-0.22,
            x=0.5,
            xanchor="center",
            title=None,
            bgcolor="rgba(0,0,0,0)",
        ),
    )
    return apply_figure_theme(fig)


def chart_card(
    graph_id: str,
    figure: go.Figure,
    label: str,
    title: str,
    description: str,
    accent: str,
    controls=None,
) -> html.Div:
    """Compact chart card for the 2x2 grid: header, chart, controls, caption."""
    children = [
        html.Div(
            style={
                "height": "5px",
                "borderRadius": "999px",
                "background": f"linear-gradient(90deg, {accent}, rgba(255,255,255,0))",
                "marginBottom": "12px",
            }
        ),
        html.Div(
            [
                html.Div(
                    label,
                    style={
                        "display": "inline-block",
                        "padding": "4px 9px",
                        "borderRadius": "999px",
                        "background": accent,
                        "color": "#0B1320",
                        "fontSize": "10px",
                        "fontWeight": "700",
                        "letterSpacing": "0.14em",
                        "textTransform": "uppercase",
                        "marginBottom": "8px",
                    },
                ),
                html.H2(
                    title,
                    style={
                        "fontFamily": THEME["title_font"],
                        "fontSize": "22px",
                        "lineHeight": "1.1",
                        "color": THEME["ink"],
                        "margin": "0 0 10px 0",
                    },
                ),
            ],
            style={"padding": "0 4px"},
        ),
        dcc.Graph(id=graph_id, figure=figure, config={"displayModeBar": False}),
    ]
    if controls is not None:
        children.append(controls)
    children.append(
        html.P(
            description,
            style={
                "margin": "12px 4px 0 4px",
                "fontSize": "13px",
                "lineHeight": "1.6",
                "color": THEME["muted"],
            },
        )
    )

    return html.Div(
        style={
            "background": "rgba(251, 248, 242, 0.94)",
            "border": f"1px solid {THEME['line']}",
            "borderRadius": "22px",
            "padding": "16px",
            "boxShadow": THEME["shadow"],
            "display": "flex",
            "flexDirection": "column",
        },
        children=children,
    )


DESC1 = (
    "Happiness clusters in Northern and Western Europe, while the lowest values fall in "
    "conflict-affected or structurally poorer regions. Gray gaps reflect countries dropped "
    "during ISO-3 harmonization — a coverage limit, not a finding."
)

DESC2 = (
    "High-spending countries sit above Low-spending countries across 2015-2023, and the "
    "gap widens through the pandemic before narrowing in 2023. This is consistent with "
    "stronger safety nets absorbing shocks, though COVID itself confounds the trend."
)

DESC3 = (
    "The fitted line slopes up, but the cloud is wide: countries with similar spending "
    "land in very different happiness ranges. Spending matters as one input among several "
    "(institutions, conflict, culture), not as a deterministic lever."
)

DESC4 = (
    "GDP is the obvious confounder, so this view tests whether tier still tracks happiness "
    "after controlling for wealth. Within similar GDP bands the High-spending series sits "
    "above the Low-spending one — early evidence that safety nets add something beyond income."
)

app = Dash(__name__)
app.title = "Social Safety Nets & Wellbeing Dashboard"

app.layout = html.Div(
    style={
        "fontFamily": THEME["body_font"],
        "padding": "28px",
        "maxWidth": "1700px",
        "margin": "0 auto",
        "background": (
            "radial-gradient(circle at top left, rgba(255,255,255,0.65), rgba(255,255,255,0) 28%), "
            "linear-gradient(180deg, #F7F1E6 0%, #F4EFE6 45%, #EEE6D8 100%)"
        ),
        "minHeight": "100vh",
        "color": THEME["ink"],
    },
    children=[
        dcc.Interval(
            id="year-player",
            interval=1200,
            n_intervals=0,
            disabled=True,
        ),
        html.Div(
            style={
                "padding": "4px 6px 14px 6px",
                "marginBottom": "10px",
                "borderBottom": f"1px solid {THEME['line']}",
                "display": "grid",
                "gridTemplateColumns": "minmax(0, 1fr) minmax(280px, 360px)",
                "gap": "24px",
                "alignItems": "end",
            },
            children=[
                html.Div(
                    [
                        html.Div(
                            "CIS 9655 · Group 6 · Phase II Dashboard",
                            style={
                                "fontSize": "11px",
                                "fontWeight": "700",
                                "letterSpacing": "0.16em",
                                "textTransform": "uppercase",
                                "color": THEME["muted"],
                                "marginBottom": "6px",
                            },
                        ),
                        html.H1(
                            "Social Safety Nets & Subjective Wellbeing",
                            style={
                                "fontFamily": THEME["title_font"],
                                "fontSize": "30px",
                                "lineHeight": "1.1",
                                "color": THEME["ink"],
                                "margin": "0 0 4px 0",
                            },
                        ),
                        html.P(
                            "Do countries with stronger social safety nets report higher subjective wellbeing?",
                            style={
                                "fontSize": "14px",
                                "color": THEME["muted"],
                                "margin": 0,
                            },
                        ),
                    ]
                ),
                html.Div(
                    [
                        html.Div(
                            "Focus on a country",
                            style={
                                "fontSize": "10px",
                                "fontWeight": "700",
                                "letterSpacing": "0.16em",
                                "textTransform": "uppercase",
                                "color": THEME["muted"],
                                "marginBottom": "6px",
                            },
                        ),
                        dcc.Dropdown(
                            id="country-filter",
                            options=COUNTRY_OPTIONS,
                            value=None,
                            placeholder="All countries — type to search…",
                            clearable=True,
                            searchable=True,
                            style={
                                "fontSize": "14px",
                                "fontFamily": THEME["body_font"],
                            },
                        ),
                        html.Div(
                            "Picking a country zooms the map, overlays its line on the time series, and highlights its dot in both scatterplots.",
                            style={
                                "fontSize": "11px",
                                "color": THEME["muted"],
                                "marginTop": "6px",
                                "lineHeight": "1.4",
                            },
                        ),
                    ]
                ),
            ],
        ),
        html.Div(
            style={
                "display": "grid",
                "gridTemplateColumns": "repeat(2, minmax(0, 1fr))",
                "gap": "20px",
                "marginBottom": "22px",
            },
            children=[
                chart_card(
                    "choropleth",
                    build_choropleth(DEFAULT_YEAR),
                    "Viz 1 · Geospatial map",
                    "Where happiness is concentrated",
                    DESC1,
                    ACCENT_COLORS["map"],
                    controls=html.Div(
                        style={
                            "margin": "10px 0 0 0",
                            "padding": "10px 14px 6px 14px",
                            "borderRadius": "14px",
                            "background": "#F7F1E6",
                            "border": f"1px solid {THEME['line']}",
                        },
                        children=[
                            html.Div(
                                [
                                    html.Div(
                                        "Year",
                                        style={
                                            "fontSize": "10px",
                                            "fontWeight": "700",
                                            "letterSpacing": "0.14em",
                                            "textTransform": "uppercase",
                                            "color": THEME["muted"],
                                        },
                                    ),
                                    html.Div(
                                        f"{DEFAULT_YEAR}",
                                        id="year-readout",
                                        style={
                                            "fontFamily": THEME["title_font"],
                                            "fontSize": "18px",
                                            "color": THEME["ink"],
                                        },
                                    ),
                                ],
                                style={
                                    "display": "flex",
                                    "justifyContent": "space-between",
                                    "alignItems": "end",
                                    "marginBottom": "6px",
                                },
                            ),
                            html.Div(
                                style={
                                    "display": "flex",
                                    "alignItems": "center",
                                    "gap": "10px",
                                    "marginBottom": "8px",
                                    "flexWrap": "wrap",
                                },
                                children=[
                                    html.Button(
                                        "Play",
                                        id="year-play-toggle",
                                        n_clicks=0,
                                        style={
                                            "border": "none",
                                            "borderRadius": "999px",
                                            "padding": "6px 14px",
                                            "background": "#7F56D9",
                                            "color": "white",
                                            "fontSize": "12px",
                                            "fontWeight": "700",
                                            "letterSpacing": "0.04em",
                                            "cursor": "pointer",
                                        },
                                    ),
                                    html.Div(
                                        "Slider drives map + spending scatter.",
                                        id="year-status",
                                        style={
                                            "fontSize": "11px",
                                            "color": THEME["muted"],
                                        },
                                    ),
                                ],
                            ),
                            dcc.Slider(
                                id="year-slider",
                                min=min(YEARS),
                                max=max(YEARS),
                                value=DEFAULT_YEAR,
                                step=1,
                                marks={int(y): str(int(y)) for y in YEARS},
                                tooltip={"placement": "bottom", "always_visible": False},
                            ),
                        ],
                    ),
                ),
                chart_card(
                    "time-series",
                    build_time_series(),
                    "Viz 2 · Time series",
                    "Whether the gap holds over time",
                    DESC2,
                    ACCENT_COLORS["time"],
                ),
                chart_card(
                    "spending-scatter",
                    build_scatter(DEFAULT_YEAR),
                    "Viz 3 · Scatterplot",
                    "Spending vs happiness",
                    DESC3,
                    ACCENT_COLORS["scatter"],
                ),
                chart_card(
                    "gdp-scatter",
                    build_gdp_vs_happiness(DEFAULT_YEAR),
                    "Viz 4 · Confounder check",
                    "GDP vs happiness, by tier",
                    DESC4,
                    ACCENT_COLORS["distribution"],
                ),
            ],
        ),
        html.Div(
            style={
                "padding": "16px 20px 6px 20px",
                "color": THEME["muted"],
                "fontSize": "12px",
                "textAlign": "center",
            },
            children=[
                "Sources: World Happiness Report, OECD Social Expenditure Database, World Bank WDI, and OECD Better Life Index. "
                "The dashboard uses the cleaned merged panel in this repository.",
            ],
        ),
    ],
)


@app.callback(
    Output("choropleth", "figure"),
    Output("spending-scatter", "figure"),
    Output("gdp-scatter", "figure"),
    Output("time-series", "figure"),
    Output("year-readout", "children"),
    Input("year-slider", "value"),
    Input("country-filter", "value"),
)
def update_views(year, country):
    return (
        build_choropleth(year, country),
        build_scatter(year, country),
        build_gdp_vs_happiness(year, country),
        build_time_series(country),
        str(year),
    )


@app.callback(
    Output("country-filter", "value"),
    Input("choropleth", "clickData"),
    prevent_initial_call=True,
)
def select_country_from_map(click_data):
    """Clicking a country on the map sets the country filter."""
    if not click_data or not click_data.get("points"):
        return no_update
    point = click_data["points"][0]
    iso = point.get("location")
    if not iso:
        return no_update
    matches = df.loc[df["iso3"] == iso, "country"]
    if matches.empty:
        return no_update
    return matches.iloc[0]


@app.callback(
    Output("year-player", "disabled"),
    Output("year-play-toggle", "children"),
    Output("year-status", "children"),
    Input("year-play-toggle", "n_clicks"),
    State("year-player", "disabled"),
    prevent_initial_call=True,
)
def toggle_year_player(n_clicks, is_disabled):
    should_play = is_disabled
    if should_play:
        return False, "Pause", "Stepping through years. Map + both scatters stay in sync."
    return True, "Play", "Slider drives map + spending scatter."


@app.callback(
    Output("year-slider", "value"),
    Input("year-player", "n_intervals"),
    State("year-slider", "value"),
    State("year-player", "disabled"),
    prevent_initial_call=True,
)
def advance_year(_n_intervals, current_year, is_disabled):
    if is_disabled:
        return no_update

    try:
        current_index = YEARS.index(current_year)
    except ValueError:
        return YEARS[0]

    next_index = (current_index + 1) % len(YEARS)
    return YEARS[next_index]


if __name__ == "__main__":
    app.run(debug=False, host="127.0.0.1", port=8050)
