# CIS 9655 — Group 6 — Phase II Dashboard

**Topic:** Social Safety Nets & Subjective Wellbeing  
**Guiding Question:** Do countries with stronger social safety nets report higher subjective wellbeing?

## What is in this repo

```text
SocialSafetyNets/
├── Documentation/
│   ├── Group6_Phase2_Dashboard.docx
│   └── Group6_Phase2_Dashboard.pdf
├── dashboard/
│   ├── dashboard.py
│   └── requirements.txt
├── data_clean/
│   ├── merged_panel.csv
│   ├── oecd_bli_clean.csv
│   ├── oecd_social_spending_clean.csv
│   ├── wdi_gdp_pcap_ppp_clean.csv
│   └── whr_clean.csv
├── full_dashboard.png
├── viz1_choropleth_2023.png
└── viz2_timeseries.png
```

## Dashboard contents

The Dash app now includes the four visualization types required by the Phase II rubric:

1. Choropleth map of happiness by country for a selected year.
2. Time-series chart of average happiness by social-spending tier, 2015-2023.
3. Scatterplot of social spending versus happiness for the selected year.
4. Box plot of happiness distribution by spending tier across the full panel.

The year slider updates the choropleth and scatterplot together.

## Run locally

```bash
cd dashboard
pip install -r requirements.txt
python dashboard.py
```

Then open `http://127.0.0.1:8050`.

## Data used

- `whr_clean.csv`: World Happiness Report panel, 2015-2023
- `oecd_social_spending_clean.csv`: OECD/OWID public social spending as % of GDP
- `wdi_gdp_pcap_ppp_clean.csv`: World Bank GDP per capita PPP
- `oecd_bli_clean.csv`: OECD Better Life Index snapshot
- `merged_panel.csv`: merged country-year analysis file used by the dashboard

## Submission checklist

For the actual Phase II submission PDF, include:

1. One screenshot of the full dashboard.
2. One screenshot for each of the four visualizations.
3. A short writeup for each visualization covering:
   - what the chart shows,
   - early findings or surprising patterns,
   - data quality issues or analytic roadblocks.

## Known limitations

- Social-spending comparisons are OECD/accession-only because that is where the comparable spending series exists.
- The World Happiness Report values are rolling averages, so an annual map is not a pure point-in-time measure.
- Country-name harmonization was needed across WHR, OECD, and WDI files.
- Ireland is a known denominator outlier because GDP inflation affects `% of GDP` social-spending measures.

## Note on the existing exported files

The files in `Documentation/` and the current PNG screenshots were exported from the earlier two-visual draft. After reviewing the updated dashboard, regenerate the screenshots and refresh the submission document so it matches the four-chart version.
